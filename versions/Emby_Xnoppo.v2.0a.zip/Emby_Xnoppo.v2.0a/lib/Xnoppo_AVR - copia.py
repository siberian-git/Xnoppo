# FILE FOR ONKYO
# thanks to miracle2k library onkyo-eiscp
# to use it install Onkyo eISCP Control, instructions, license usage and so are here https://github.com/miracle2k/onkyo-eiscp
# Gracias a miracle2k por la libreria onkyo-eiscp
# para usarlo instalar Onkyo eISCP Control, instrucciones, licencia de uso y demas estan en https://github.com/miracle2k/onkyo-eiscp
#
# Onkyo eISCP Control License
# The MIT License
#
# Copyright (c) 2010 Will Nowak
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

import eiscp
import logging
import time

def get_parametro2(texto,valor_actual):
    valor = input(texto+": ")
    if valor=="":
        valor=valor_actual
    return(valor)

def get_parametro_int2(texto,valor_actual):
    valor=''
    while valor=='':
        valor = input(texto+": ")
        if valor=="":
            result=valor_actual
            valor='0'
        else:
            try:
                result=int(valor)
            except:
                print('Introduzca un numero entero')
    return(result)

def get_confirmation2(texto):
    valor=''
    while valor!='s' and valor!='n':
        valor = input(texto+": ")
        if valor=="s":
            return(0)
        elif valor=="n":
            return(1)
        elif valor=="S":
            return(0)
        elif valor=="N":
            return(1)
        else:
            print('Responda s,S,n o N')

def av_config(config):

    es_correcto=False
    while es_correcto==False:
        print("A continuacion se solicitaran los parametros relativos al AV, dejarlo en blanco y pulsar ENTER deja el parametro al valor actual")
        av_ip=get_parametro2("Introduzca el valor para la ip, valor actual " + config["AV_Ip"],config["AV_Ip"])
        print ("AV IP                     : %s" % av_ip)
        result=get_confirmation2('Esta es la nueva configuracion, es correcta? (s/n)')
        if result==0:
            es_correcto=True
            config["AV_Ip"]=av_ip
    print("Pendiente el resto de parametros")
    
def av_test(config):
    try:
        receiver = eiscp.eISCP(config["AV_Ip"])
        onk_status = receiver.command('power query')
        print("-----------------------------------------------------------")
        print("               Test Conexion AV Onkyo OK               ")
        print("-----------------------------------------------------------")
        return("OK")
    except:
        print("-----------------------------------------------------------")
        print("               Test Conexion AV Onkyo NO OK               ")
        print("-----------------------------------------------------------")
        return("Error")
    
def av_check_power(config):
    logging.info('Onkyo Check AV POWER')
    try:
        receiver = eiscp.eISCP(config["AV_Ip"])
        onk_status = receiver.command('power query')
        logging.info('Onkyo Power Status: %s',onk_status[1])
        if onk_status[1]==('standby', 'off'):
           logging.info('Cambiamos a on')
           receiver.command('power on')
        receiver.disconnect()
        return("OK")
    except:
        return("Error")
   
def av_change_hdmi(config):
    logging.info('Onkyo Check HDMI Input')
    try:
        receiver = eiscp.eISCP(config["AV_Ip"])
        onk_input = receiver.command('source query')
        logging.info('Onkyo Input Status: %s',onk_input[1])
        if onk_input[1]==('video6', 'pc'):
           logging.info('Input Correcta')
        else:
           logging.info('Cambiamos la Entrada')
           time.sleep(2)
           receiver.command('source pc')
        receiver.disconnect()
        return("OK")
    except:
        return("Error en el cambio")

def av_power_off(config):
    logging.info('Llamada a av_power_off')
    return("OK")

