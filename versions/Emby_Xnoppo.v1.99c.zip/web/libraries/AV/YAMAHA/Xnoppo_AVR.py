# FILE FOR YAMAHA
import logging
import request

def add_hdmi(id, name, param, hdmi_list):
    hdmi_list_tmp=hdmi_list
    hdmi_input={}
    hdmi_input["Id"]=id
    hdmi_input["Name"]=name
    hdmi_input["Param"]=param
    hdmi_list_tmp.append(hdmi_input)
    return(hdmi_list_tmp)

def get_hdmi_list(config):
    hdmi_intput_list=[]
    hdmi_intput_list=add_hdmi(1,"HDMI1",'HDMI1',hdmi_intput_list)
    hdmi_intput_list=add_hdmi(2,"HDMI2",'HDMI2',hdmi_intput_list)
    hdmi_intput_list=add_hdmi(3,"HDMI3",'HDMI3',hdmi_intput_list)
    hdmi_intput_list=add_hdmi(4,"HDMI4",'HDMI4',hdmi_intput_list)
    hdmi_intput_list=add_hdmi(5,"HDMI5",'HDMI5',hdmi_intput_list)
    hdmi_intput_list=add_hdmi(6,"HDMI6",'HDMI6',hdmi_intput_list)
    hdmi_intput_list=add_hdmi(7,"HDMI7",'HDMI7',hdmi_intput_list)
    hdmi_intput_list=add_hdmi(8,"HDMI8",'HDMI8',hdmi_intput_list)
    hdmi_intput_list=add_hdmi(9,"HDMI9",'HDMI9',hdmi_intput_list)
    
    return(hdmi_intput_list)

def av_config(config):
    print('Este es el fichero estandar de AV, si dispone de uno para su AV copielo en lib con el nombre Xnoppo_AVR.py')

def av_test(config):
    print("-----------------------------------------------------------")
    print("               Test AV Dummy OK               ")
    print("-----------------------------------------------------------")

def av_check_power(config):
    url = 'http://' + config["AV_Ip"] + '/YamahaRemoteControl/ctrl'
    message_data = '<YAMAHA_AV cmd="PUT"><System><Power_Control><Power>On</Power></Power_Control></System></YAMAHA_AV>'
    headers=""
    response = requests.post(url, data=message_data, headers=headers)
    logging.info('Llamada a av_check_power')
    return("OK")
    
def av_change_hdmi(config):
    url = 'http://' + config["AV_Ip"] + '/YamahaRemoteControl/ctrl'
    message_data = '<Main_Zone><Input><Input_Sel>' + config["AV_Input"]+ '</Input_Sel></Input></Main_Zone>'
    headers=""
    response = requests.post(url, data=message_data, headers=headers)
    logging.info('Llamada a av_change_hdmi')
    return("OK")

def av_power_off(config):
    url = 'http://' + config["AV_Ip"] + '/YamahaRemoteControl/ctrl'
    message_data = '<YAMAHA_AV cmd="PUT"><System><Power_Control><Power>Standby</Power></Power_Control></System></YAMAHA_AV>'
    headers=""
    response = requests.post(url, data=message_data, headers=headers)
    logging.info('Llamada a av_power_off')
    return("OK")
